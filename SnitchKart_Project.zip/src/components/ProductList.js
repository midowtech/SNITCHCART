// Product list component
